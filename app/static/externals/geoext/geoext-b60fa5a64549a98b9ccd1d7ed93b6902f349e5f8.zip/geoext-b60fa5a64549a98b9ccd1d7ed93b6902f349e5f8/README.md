# GeoExt

## JavaScript Toolkit for Rich Web Mapping Applications

GeoExt brings together the geospatial know how of 
[OpenLayers](http://openlayers.org) with the user interface savvy of 
[Ext JS](http://www.sencha.com/products/js/) to help you build powerful desktop 
style GIS apps on the web with JavaScript.

Have a look at the [projects homepage](http://geoext.org/) to find 
[documentation](http://geoext.org/docs.html), 
[examples](http://geoext.org/examples.html#examples) and the 
[bug-tracker](http://trac.geoext.org/).

