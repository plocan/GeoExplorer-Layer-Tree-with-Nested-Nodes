buildkit.js
===========

Build utilities for JavaScript projects.

Depends on [RingoJS](http://ringojs.org/).

Run the tests with the following:

    ringo -m lib tests/all.js
    
(This assumes `lib` is the path to the `buildkit/lib` directory.)
