This is a basic Stick application. To run it launch ringo with the main script:

    ringo main.js

Then point your browser to this URL:

    http://localhost:8080/

Run with -h or --help for more options.
